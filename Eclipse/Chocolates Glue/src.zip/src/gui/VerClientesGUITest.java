package gui;

import javax.swing.JFrame;

public class VerClientesGUITest {


	public static void main(String[] args) {
		VerClientesGUI ver = new VerClientesGUI();
		ver.setVisible(true);
		ver.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}
