package gui;

import javax.swing.JFrame;

public class VerProductosGUITest {

	public static void main(String[] args) {
		VerProductosGUI ver = new VerProductosGUI();
		ver.setVisible(true);
		ver.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}
