package classes;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

/*
 * La clase Adminstrador se encarga de manejar todos los aspectos referentes a la n�mina de la empresa*/
public class Administrador extends Empleados{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7735783247027783924L;
	private static int cantidadAdministradores;//constante que muestra cuantos administradores tiene la empresa. M�nimo debe de haber uno
	
	
	/*
	 * Los constructores de la clase Administrador solo difieren de los constructores de la clase
	 * Empleados en que se instancia al String que conservar� la contrase�a del Administrador*/
	public Administrador(){
		super();
	}
	public Administrador(String nombre, double cedulaCiudadania, double salario, double telefono, String correoElectronico, String fechaNacimiento, String contrasenia){
		super(nombre, cedulaCiudadania, salario, telefono, correoElectronico, fechaNacimiento, contrasenia);
	}
	
	/*
	 * El m�todo setCantidadAdminstradores retorna true cuando el valor ingresado es mayor a 0
	 * Esto implica a que siempre deba de haber por lo menos uno de estos*/
	public static boolean setCantidadAdministradores(int cantidadAdministradores) {
		if(cantidadAdministradores > 0){
			Administrador.cantidadAdministradores = cantidadAdministradores;
			return true;
		}
		else{
			return false;
		}
	}
	public static int getCantidadAdministradores() {
		return cantidadAdministradores;
	}
	
	
	/*
	 * El m�todo toString retorna los atributos de un Administrador determinado*/
	public String toString(){
		return ("Adminstrador;\n"+super.toString());
	}
	
	/*
	 * El m�todo contratarEmpleado agrega un nuevo empleado a la base de datos del sistema*/
	public void contratarEmpleado(Empleados empleado, Empresa empresa){
		HashMap<Double, Empleados> empleados = empresa.getEmpleados();
		empleados.put(((Double)empleado.getCedulaCiudadania()), empleado);
		empresa.setEmpleados(empleados);
	}
	
	/*
	 * El m�todo despedirEmpleado elimina a un determinado Empleado de la base de datos del sistema
	 * de la empresa, en caso de que un adiminstrador intente despedir a otro el m�todo retorna valor
	 * falso y no lo despide ya que un Administrador no puede despedir a otro*/
	public boolean despedirEmpleado(Empleados empleado, Empresa empresa){
		boolean ret = false;
		HashMap<Double, Empleados> empleados = empresa.getEmpleados();
		empleados.get(empleado.getCedulaCiudadania());
		if(((Administrador)empleado).getContrasenia().equals(null)){/*revisa si la persona a la que se est�
			intentando despedir tiene una contrase�a asignada que en este caso solo la tienen los admins y
			en un dado caso que no tega, procede a despedirlo ya que un administrador no puede despedir a otro*/
			empleados.remove((Double)empleado.getCedulaCiudadania());
			ret = true;
		}
		empresa.setEmpleados(empleados);
		return ret;
	}
	/*
	 * El m�todo pagar salario es llamado por el administrador de una empresa al momento de
	 * determinarse que es el momento en el que cada uno de los trabajadores cobre su sueldo*/
	public void pagarSalario(Empresa empresa){
		HashMap<Double, Empleados> empleados = empresa.getEmpleados();
		Set<Double> cedulas = empleados.keySet();
		for(Iterator<Double> iterador = cedulas.iterator();iterador.hasNext();){
			Double cedulaTemp = iterador.next();
			empleados.get(cedulaTemp).cobrarSalario(empresa);
		}
	}
	
	/*
	 * El m�todo cambiarSalario modifica los valores de un Empleado determinado, retorna falso al no
	 * poderse llevar a cabo el proceso por salario propuesto menor al SSMLV perteneciente a la clase
	 * Empleados*/
	public boolean cambiarSalario(Empleados empleado, Empresa empresa, double salario){
		return empresa.getEmpleados().get(empleado.getCedulaCiudadania()).setSalario(salario);
	}
	
	/*
	 * El m�todo agregarProveedor a�ade un nuevo proveedor al conjunto de proveedores de productos
	 * de la empresa*/
	public void agregarProveedor(Proveedor proveedor, Empresa empresa){
		HashMap<Double, Proveedor> proveedores = empresa.getProveedores();
		proveedores.put(((Double)proveedor.getNit()), proveedor);
		empresa.setProveedores(proveedores);
	}
	/*
	 * El m�todo agregarProducto recibe un Productos como par�metro y lo agrega del otro par�metro al HashMap de Empresa*/
	public void agregarProducto(Empresa empresa, Productos producto){
		empresa.agregarProducto(producto);
	}
	
	/*
	 * El m�todo modificar se encarga de cambiar todos los atributos de un objeto instanciado
	 * en la clase Administrador*/
	public void modificar(String nombre, double cedulaCiudadania, double salario, double telefono, String correoElectronico, String fechaNacimiento, String contrasenia){
		this.setNombre(nombre);
		this.setCedulaCiudadania(cedulaCiudadania);
		this.setSalario(salario);
		this.setTelefono(telefono);
		this.setCorreoElectronico(correoElectronico);
		this.setFechaNacimiento(fechaNacimiento);
		this.setContrasenia(contrasenia);
	}
}